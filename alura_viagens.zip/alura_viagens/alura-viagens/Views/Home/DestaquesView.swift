//
//  ContentView.swift
//  alura-viagens
//
//  Created by Ândriu Felipe Coelho on 03/02/20.
//  Copyright © 2020 Ândriu Felipe Coelho. All rights reserved.
//

import SwiftUI

struct DestaquesView: View {

    //Viariável de ambiente, para configurar o tamanho de acordo com o dispositivo (iPhone ou iPad)
    @Environment(\.horizontalSizeClass) var horizontalSizeClass

    var body: some View {
        
        NavigationView { //método para realizar a navegação de telas
            GeometryReader { view in // método para ter acesso a variável view, para alterar tamanhos de acordo com o frame da view
                VStack { //vertical stack
                    HeaderView() //modo que chama a outra View de uma struct
                        .frame(width: view.size.width, height: self.horizontalSizeClass == .compact ? 225 : 350, alignment: .top) //self.horizontalSizeClass == .compact ? 200 : 310 -> modo para setar constraints diferentes para iPhone ou iPad
                    List(viagens) { viagem in //tipo um for each
                        //método da NavigationLink que de fato vai chamar a próxima tela
                        NavigationLink(destination: MapaView(coordenada:  viagem.localizacao).navigationBarTitle("Localização")) {
                            CelulaViagemView(viagem: viagem)
                        }
                    }.navigationBarTitle("") //remover o "back" do botão voltar
                }
            }
            .edgesIgnoringSafeArea(.all) //ignora a safe area
        }.navigationViewStyle(StackNavigationViewStyle()) //método usado para poder ter a navegação no iPad - configurou o título como Localização
    }
}

struct DestaquesView_Previews: PreviewProvider {
    static var previews: some View {
        DestaquesView()
    }
}
