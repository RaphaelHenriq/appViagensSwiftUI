//
//  ContentView.swift
//  alura-viagens
//
//  Created by Raphael Henrique on 3/2/21.
//  Copyright © 2021 Ândriu Felipe Coelho. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView { // criar a Tabbar com 2 itens
            DestaquesView()
                .tabItem {
                    Text("Destaques")
                    Image("icone-destaques")
                }
            ListaDePacotesView()
                .tabItem {
                    Text("Pacotes")
                    Image("icone-mala")
                }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
